# 🚚 Roho Rider System - Visual Architecture

## System Components Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          ROHO NOURISH DELIVERY SYSTEM                       │
└─────────────────────────────────────────────────────────────────────────────┘

                    🛒 CUSTOMER                      👤 RIDER
                       SIDE                            SIDE
                    ────────                        ────────

    ┌──────────────────────────────────────────────────────────┐
    │                    WhatsApp Flows                        │
    │                                                          │
    │ Customer Bot                    Rider Bot               │
    │ ├─ WELCOME                      ├─ RIDER_HOME           │
    │ ├─ SELECTING_FOOD               ├─ VIEWING_QUEUE        │
    │ ├─ CONFIRM_ORDER                ├─ BOOKING_CONFIRMED    │
    │ ├─ PAYMENT                      ├─ ON_DELIVERY          │
    │ └─ ORDER_COMPLETE               └─ DELIVERY_COMPLETE    │
    └──────────────────────────────────────────────────────────┘
                            ↓ ↓
            ┌───────────────────────────────┐
            │      Express Server           │
            │  (POST /webhook)              │
            │  - Validate Twilio request    │
            │  - Route to correct bot       │
            │  - Send response              │
            └───────────────────────────────┘
                            ↓
            ┌───────────────────────────────┐
            │    Firebase Real-time DB      │
            │   (Session State)             │
            │  /sessions/{phone}            │
            │  - Current step               │
            │  - Temporary data             │
            └───────────────────────────────┘
                            ↓
            ┌───────────────────────────────┐
            │    Firestore Database         │
            │   (Persistent Data)           │
            └───────────────────────────────┘
```

---

## Order Lifecycle Flow Diagram

```
START: Customer Orders
    │
    ├─ Customer: "Hi"
    │   └─ Bot: Shows welcome menu
    │
    ├─ Customer: "1" (Order Lunch)
    │   └─ Bot: Shows meal options
    │
    ├─ Customer: "1" (Select meal)
    │   └─ Bot: Asks for location
    │
    ├─ Customer: "Westlands Tower"
    │   └─ Bot: Shows payment prompt
    │
    ├─ Customer: "confirm"
    │   └─ [createOrder() called]
    │      ├─ Save to /orders/{orderId}
    │      ├─ assignGroupToOrder("Westlands Tower")
    │      │   └─ Returns: "nairobi_cbd" ✅
    │      │
    │      └─ createOrderQueueEntry()
    │         └─ Save to /order_queue/{orderId}
    │            └─ status: "pending_booking"
    │
    └─ ✅ ORDER CREATED & IN RIDER QUEUE
        │
        ├─ Bot: "Order placed. ID: ORD-xxx"
        │
        └─ Visible to all "nairobi_cbd" riders


MIDDLE: Rider Claims Order
    │
    ├─ Rider: "Hi"
    │   └─ Bot: Shows rider menu
    │
    ├─ Rider: "1" (View Queue)
    │   └─ [getGroupPendingOrders("nairobi_cbd")]
    │      └─ Bot: Shows pending orders
    │
    ├─ Rider: "1" (Book first order)
    │   └─ [bookOrder(orderId, riderId, riderName)]
    │      ├─ Create /bookings/{bookingId}
    │      │  └─ status: "booked"
    │      │
    │      ├─ Create /payments/{bookingId}
    │      │  └─ status: "held" 💰 (funds locked)
    │      │
    │      ├─ Update /order_queue/{orderId}
    │      │  └─ status: "booked"
    │      │
    │      └─ Other riders: Order removed from their queue ✅
    │
    └─ ✅ BOOKING CONFIRMED & FUNDS HELD


END: Rider Delivers & Funds Released
    │
    ├─ Rider: "1" (Ready for pickup)
    │   └─ updateBookingStatus() → "pickup_ready"
    │
    ├─ Rider: "1" (In transit)
    │   └─ updateBookingStatus() → "in_transit"
    │
    ├─ Rider: "1" (Arrived)
    │   └─ updateBookingStatus() → "delivered"
    │
    ├─ Rider: "1" (Confirm delivery)
    │   └─ [confirmDeliveryAndReleaseFunds(bookingId)]
    │      ├─ Update /bookings/{bookingId}
    │      │  └─ status: "completed"
    │      │
    │      ├─ Update /payments/{bookingId}
    │      │  ├─ status: "held" → "released" ✅
    │      │  └─ releasedAt: timestamp
    │      │
    │      ├─ Update /orders/{orderId}
    │      │  └─ status: "delivered"
    │      │
    │      └─ Funds → Rider's wallet 💰
    │
    └─ ✅ DELIVERY COMPLETE, FUNDS RELEASED
```

---

## Firestore Collections Diagram

```
┌────────────────────────────────────────────────────────────────┐
│                    FIRESTORE DATABASE                          │
├────────────────────────────────────────────────────────────────┤

/rider_groups                          /riders
├─ nairobi_cbd                         ├─ whatsapp:+254712345678
│  ├─ name: "Nairobi CBD"             │  ├─ name: "John Mwangi"
│  ├─ locationKeywords: [...]         │  ├─ phone: "whatsapp:+254712345678"
│  ├─ maxConcurrentOrders: 10         │  ├─ groupId: "nairobi_cbd"
│  └─ isDefault: true                 │  ├─ status: "active"
│                                     │  └─ totalDeliveries: 42
└─ south_nairobi
   └─ ...

/orders                               /order_queue
├─ ORD-1734506400000                 ├─ ORD-1734506400000
│  ├─ orderId: "ORD-1734506400000"  │  ├─ orderId: "ORD-1734506400000"
│  ├─ mealName: "Beef & Mukimo"     │  ├─ groupId: "nairobi_cbd"
│  ├─ location: "Westlands Tower"   │  ├─ status: "booked" ← PENDING → BOOKED
│  ├─ price: 320                     │  ├─ bookedBy: "whatsapp:+254712345678"
│  ├─ phone: "whatsapp:+254797354429│  ├─ bookedAt: "2025-12-17T10:05:00Z"
│  ├─ status: "delivered"            │  └─ ...
│  └─ createdAt: "2025-12-17T10:00Z" │

/bookings                             /payments
├─ BK-1734506400000-xyz123           ├─ BK-1734506400000-xyz123
│  ├─ bookingId: "BK-..."            │  ├─ bookingId: "BK-..."
│  ├─ orderId: "ORD-..."             │  ├─ amount: 320
│  ├─ riderId: "whatsapp:+254..."    │  ├─ status: "released" ← held → released
│  ├─ riderName: "John Mwangi"       │  ├─ createdAt: "2025-12-17T10:05:00Z"
│  ├─ status: "completed"            │  ├─ releasedAt: "2025-12-17T10:50:00Z"
│  ├─ bookingConfirmedAt: "10:05"    │  └─ ...
│  ├─ pickupAt: "10:10"              │
│  ├─ inTransitAt: "10:15"           │
│  ├─ deliveredAt: "10:45"           │
│  └─ completedAt: "10:50"           │

└────────────────────────────────────────────────────────────────┘
```

---

## Payment State Machine Diagram

```
                    ┌─────────────────────┐
                    │   ORDER PLACED      │
                    │  (Not yet booked)   │
                    └──────────┬──────────┘
                               │
                        Customer creates order
                               │
                    ┌──────────▼──────────┐
                    │  PENDING_BOOKING    │
                    │  Order in queue     │
                    └──────────┬──────────┘
                               │
                        Rider books order
                               │
        ┌──────────────────────┴─────────────────────────┐
        │                                                 │
    [PAYMENT HELD]                                        │
    ┌───────────────┐                          ┌─────────▼──────┐
    │  /payments    │                          │  /bookings     │
    │ status: held  │◄────────────────────────►│ status: booked │
    │ amount: 320   │                          └────────────────┘
    │ (locked) 💰   │
    └───────┬───────┘
            │
      Rider updates status
      (pickup → transit → delivered)
            │
            │ Rider confirms delivery
            │
    ┌───────▼──────────────┐
    │ confirmDelivery()    │
    │ called               │
    └───────┬──────────────┘
            │
    ┌───────▼──────────────┐
    │ PAYMENT RELEASED     │
    │ /payments            │
    │ status: released     │
    │ amount: 320 ✅ 💰    │
    │ (accessible)         │
    └──────────────────────┘
            │
            │ Funds transferred to rider
            │ (via admin dashboard)
            │
    ┌───────▼──────────────┐
    │ RIDER'S WALLET       │
    │ Funds available      │
    └──────────────────────┘
```

---

## Rider State Machine

```
START
  │
  └─ Rider sends "Hi"
     │
     ▼
┌──────────────────────┐
│   RIDER_HOME         │
│   (Main Menu)        │
│ 1. View Queue        │
│ 2. My Bookings       │
│ 3. Account           │
└──────────┬───────────┘
           │
     Rider picks "1"
           │
     ┌─────▼────────────────────┐
     │ VIEWING_QUEUE            │
     │ Shows pending orders     │
     │ - Order #1, #2, #3, ...  │
     └─────┬────────────────────┘
           │
     Rider picks order (e.g., "1")
           │
     ▼─────────────────────────────────┐
┌──────────────────────────────────────▼─┐
│  BOOKING_CONFIRMED                     │
│  Order booked!                         │
│  1. Ready for pickup                   │
│  2. Cancel booking                     │
└──────────────┬───────────────────────┬─┘
               │                       │
         Rider picks "1"        Rider picks "2"
               │                       │
         ┌─────▼─────────┐     ┌──────▼──────┐
         │ ON_DELIVERY   │     │ Back to     │
         │               │     │ RIDER_HOME  │
         │ 1. In transit │     └─────────────┘
         │ 2. View       │
         │ 3. All        │
         │ 4. Home       │
         └─────┬─────────┘
               │
         Rider updates status
         (pickup → transit → delivered)
               │
         ┌─────▼──────────────────┐
         │ DELIVERY_COMPLETE      │
         │ 1. Confirm delivery    │
         │ 2. Report issue        │
         └─────┬────────┬─────────┘
               │        │
         Pick "1"   Pick "2"
               │        │
         ┌─────▼───┐  ┌─▼────────────┐
         │ Confirm │  │ Issue Report │
         │ Delivery│  │              │
         │         │  └──────────────┘
         │ Funds   │
         │Released │
         │ ✅ 💰   │
         │         │
         │ Back to │
         │RIDER_HOME
         └─────────┘
```

---

## Group Assignment Logic Flow

```
┌─────────────────────────────────────────┐
│   Customer enters location              │
│   "Britam Tower, Westlands"             │
└────────────────┬────────────────────────┘
                 │
    ┌────────────▼────────────┐
    │ getRiderGroups()        │
    │ Get all zones from DB   │
    └────────────┬────────────┘
                 │
    ┌────────────▼────────────────────────┐
    │ For each group:                     │
    │ Check locationKeywords              │
    └────────────┬────────────────────────┘
                 │
    ┌────────────▼────────────────────────┐
    │ "nairobi_cbd"                       │
    │ keywords: ["westlands", "cbd", ...]│
    │                                     │
    │ "westlands" in "britam tower..." ✓  │
    │ MATCH FOUND!                        │
    └────────────┬────────────────────────┘
                 │
    ┌────────────▼────────────────────────┐
    │ Return: "nairobi_cbd"               │
    └────────────┬────────────────────────┘
                 │
    ┌────────────▼────────────────────────┐
    │ Create queue entry with groupId     │
    │ /order_queue/{orderId}              │
    │ groupId: "nairobi_cbd"              │
    └────────────┬────────────────────────┘
                 │
    ┌────────────▼────────────────────────┐
    │ ✅ Order visible to CBD riders      │
    └────────────────────────────────────┘
```

---

## Complete Data Flow Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       COMPLETE ROHO DELIVERY FLOW                           │
└─────────────────────────────────────────────────────────────────────────────┘

STEP 1: Customer Order
┌──────────────────────────┐
│ Customer WhatsApp Bot    │
│ Selects meal, location   │
└─────────┬────────────────┘
          │
          ▼
┌──────────────────────────────────────────┐
│ BotEngine.createOrder()                  │
├──────────────────────────────────────────┤
│ 1. Save /orders/{orderId}                │
│ 2. Assign group based on location        │
│ 3. Create /order_queue/{orderId}         │
│ 4. status: pending_booking               │
└─────────┬──────────────────────────────┬─┘
          │                              │
          │                              │
    Firebase                      RTDB: /sessions
  (Persistent)                  (Ephemeral)
          │
          ▼
┌──────────────────────────────────────────┐
│ ✅ Order in queue, visible to riders    │
└──────────────────────────────────────────┘


STEP 2: Rider Books Order
┌──────────────────────────┐
│ Rider WhatsApp Bot       │
│ Views & books order      │
└─────────┬────────────────┘
          │
          ▼
┌──────────────────────────────────────────┐
│ RiderService.bookOrder()                 │
├──────────────────────────────────────────┤
│ 1. Create /bookings/{bookingId}          │
│ 2. Create /payments/{bookingId} HELD     │
│ 3. Update /order_queue status: booked    │
│ 4. Atomic transaction (no double-book)   │
└─────────┬──────────────────────────────┬─┘
          │                              │
          │                              │
    Firebase              Payment Locked 💰
          │
          ▼
┌──────────────────────────────────────────┐
│ ✅ Booking confirmed, funds held         │
└──────────────────────────────────────────┘


STEP 3: Rider Delivers & Updates Status
┌──────────────────────────────────────────┐
│ Rider WhatsApp Bot                       │
│ Updates: pickup → transit → delivered    │
└─────────┬──────────────────────────────┬─┘
          │                              │
          ▼                              │
┌──────────────────────────────────────────┐
│ RiderService.updateBookingStatus()       │
│ Updates /bookings/{bookingId}            │
│ - pickupAt timestamp                     │
│ - inTransitAt timestamp                  │
│ - deliveredAt timestamp                  │
└─────────┬──────────────────────────────┬─┘
          │                              │
          │                              │
    Firebase                      RTDB: /sessions
          │
          ▼
┌──────────────────────────────────────────┐
│ ✅ Delivery tracked & verified           │
└──────────────────────────────────────────┘


STEP 4: Confirm Delivery & Release Funds
┌──────────────────────────────────────────┐
│ Rider: "Confirm delivery"                │
└─────────┬──────────────────────────────┬─┘
          │                              │
          ▼                              │
┌──────────────────────────────────────────┐
│ RiderService.confirmDeliveryAndRelease() │
├──────────────────────────────────────────┤
│ 1. /bookings status: completed           │
│ 2. /payments status: held → RELEASED ✅  │
│ 3. /orders status: delivered             │
│ 4. Payment timestamp: releasedAt         │
└─────────┬──────────────────────────────┬─┘
          │                              │
          │                              │
    Firebase                    Payment Released 💰
          │
          ▼
┌──────────────────────────────────────────┐
│ ✅ Delivery complete, funds accessible   │
│    Rider can see payment in wallet       │
└──────────────────────────────────────────┘
```

---

**Built for Roho Nourish** 🌿 Fuel for your day.

See documentation files for implementation details:
- `README_RIDER_SYSTEM.md`
- `RIDER_BOOKING_DEEP_DIVE.md`
- `QUICK_REFERENCE.md`
